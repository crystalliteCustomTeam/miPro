<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOne;

class BrandTarget extends Model
{
    use HasFactory;
    protected $table = 'brandtarget';
    protected $fillable = [
        "BrandID",
        "Year",
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"

    ];

    public function brandoftarget():HasOne
    {
        return $this->hasOne(Brand::class,'id','BrandID');
    }
}
